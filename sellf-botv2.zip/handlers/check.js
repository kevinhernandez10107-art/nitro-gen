
const targetServerID = '1165841460751507468'; 
module.exports = { targetServerID };
